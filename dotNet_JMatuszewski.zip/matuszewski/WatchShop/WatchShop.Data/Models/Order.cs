﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WatchShop.Domain
{
    public class Order : Entity
    {
        public string UserId { get; set; }
        public virtual ApplicationUser User { get; set; }

        public int OrderStatusId { get; set; }
        public OrderStatus OrderStatus { get; set; }

        public DateTime? ShipmentDate { get; set; }

        public int ItemsQty { get; set; }
        public decimal ItemsPrice { get; set; }
    }
}
