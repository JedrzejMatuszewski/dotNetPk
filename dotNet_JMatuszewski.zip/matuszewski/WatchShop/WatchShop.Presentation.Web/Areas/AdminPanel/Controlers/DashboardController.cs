﻿using DevExtreme.AspNet.Data;
using DevExtreme.AspNet.Mvc;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using WatchShop.Application;
using WatchShop.Data;
using WatchShop.Domain;
using WatchShop.Presentation.Web.Utils;

namespace WatchShop.Presentation
{
    [Area(AreaNames.AdminPanel)]
    public class DashboardController : Controller
    {
        private readonly IMarkRepository _markRepository;
        private readonly IShopService _shopService;
        private readonly IWebHostEnvironment _webHostEnvironment;
        private readonly UserManager<ApplicationUser> _userManager;

        public DashboardController(IMarkRepository markRepository, IShopService shopService,
            IWebHostEnvironment webHostEnvironment, UserManager<ApplicationUser> userManager)
        {
            this._markRepository = markRepository;
            this._shopService = shopService;
            this._webHostEnvironment = webHostEnvironment;
            this._userManager = userManager;
        }

        
        public async Task<IActionResult> Index()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> ProductList()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> ProductGetAllToLookup(DataSourceLoadOptionsBase loadOptions)
        {
            return Json(await _shopService.ProductGetAll(loadOptions));
        }

        public async Task<IActionResult> ProductAdd()
        {
            return View(new ProductAddVM());
        }

        public async Task<IActionResult> ProductEdit(int? productId)
        {
            if (productId == null)
            {
                return BadRequest("Wrong data");
            }

            var model = await _shopService.GetProductEditVM((int)productId);
            return View(model);
        }

        [HttpPost]
        public async Task<ActionResult> ProductEditPerform(ProductEditVM model)
        {

            try
            {
                if (model.IsGaleryUpdate)
                {
                    var galleryImages = await this.SaveFiles(model.Photos);
                    model.PhotoNames = galleryImages;
                }
                await _shopService.EditProduct(model);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }

            return RedirectToAction("Detalis", "Products", new { area = AreaNames.ShopPanel, id = model.ProductId });
        }


        [HttpPost]
        public async Task<ActionResult> ProductNew(ProductAddVM model)
        {

            try
            {
                var galleryImages = await this.SaveFiles(model.Photos);
                model.PhotoNames = galleryImages;
                await _shopService.AddNewProduct(model);
            }
            catch (Exception ex)
            {
                return BadRequest();
            }

            return RedirectToAction("Index");
        }


        private async Task<IEnumerable<string>> SaveFiles(IEnumerable<IFormFile> files)
        {
            var fileNames = new List<string>();

            foreach (IFormFile file in files)
            {
                var path = Path.Combine(_webHostEnvironment.WebRootPath, "uploads\\gallery");
                var uniqueFileName = Guid.NewGuid().ToString() + "_" + file.FileName;

                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }

                using (var fileStream = System.IO.File.Create(Path.Combine(path, uniqueFileName)))
                {
                    file.CopyTo(fileStream);
                }

                fileNames.Add(uniqueFileName);
            }

            return fileNames;
        }

        #region Mark
        public async Task<IActionResult> MarkManagement()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> MarkGet(DataSourceLoadOptionsBase loadOptions)
        {
            return Json(await _shopService.MarkGet(loadOptions));
        }

        [HttpGet]
        public object Get(DataSourceLoadOptions loadOptions)
        {
            return DataSourceLoader.Load(new List<Mark> { new Mark { Id= 1, Name="TST" },
            new Mark { Id= 2, Name="Marka2" }}, loadOptions);
        }

        [HttpPost]
        public async Task<IActionResult> MarkPost(string values)
        {
            try
            {
                await _shopService.MarkPost(values);
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest("Wystąpił błąd");
            }
        }
        [HttpPut]
        public async Task<IActionResult> MarkPut(int key, string values)
        {
            try
            {
                await _shopService.MarkPut(key, values);
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest("Wystąpił błąd");
            }
        }
        [HttpDelete]
        public async Task<IActionResult> MarkDelete(int key)
        {
            try
            {
                await _shopService.MarkDelete(key);
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest("Wystąpił błąd");
            }
        }

        #endregion

        #region OrderStatus
        public async Task<IActionResult> OrderStatusManagement()
        {
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> OrderStatusGet(DataSourceLoadOptionsBase loadOptions)
        {
            return Json(await _shopService.OrderStatusGet(loadOptions));
        }
        [HttpPost]
        public async Task<IActionResult> OrderStatusPost(string values)
        {
            try
            {
                await _shopService.OrderStatusPost(values);
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest("Wystąpił błąd");
            }
        }
        [HttpPut]
        public async Task<IActionResult> OrderStatusPut(int key, string values)
        {
            try
            {
                await _shopService.OrderStatusPut(key, values);
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest("Wystąpił błąd");
            }
        }
        [HttpDelete]
        public async Task<IActionResult> OrderStatusDelete(int key)
        {
            try
            {
                await _shopService.OrderStatusDelete(key);
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest("Wystąpił błąd");
            }
        }
        #endregion

        #region Address

        [HttpGet]
        public async Task<IActionResult> AddressGetForUser(DataSourceLoadOptionsBase loadOptions)
        {
            ApplicationUser user = null;
            if (HttpContext.User != null)
            {
                user = await _userManager.GetUserAsync(HttpContext.User);
            }

            if (user == null)
            {
                return BadRequest("Nie znaleziono użytkownika");
            }

            return Json(await _shopService.AddressGetForUser(loadOptions, user.Id));
        }
        [HttpPost]
        public async Task<IActionResult> AddressPost(string values)
        {
            try
            {
                ApplicationUser user = null;
                if (HttpContext.User != null)
                {
                    user = await _userManager.GetUserAsync(HttpContext.User);
                }

                if (user == null)
                {
                    return BadRequest("Nie znaleziono użytkownika");
                }

                await _shopService.AddressPost(values, user.Id);
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest("Wystąpił błąd");
            }
        }
        [HttpPut]
        public async Task<IActionResult> AddressPut(int key, string values)
        {
            try
            {
                await _shopService.AddressPut(key, values);
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest("Wystąpił błąd");
            }
        }
        [HttpDelete]
        public async Task<IActionResult> AddressDelete(int key)
        {
            try
            {
                await _shopService.OrderStatusDelete(key);
                return Ok();
            }
            catch (Exception)
            {
                return BadRequest("Wystąpił błąd");
            }
        }
        #endregion

        #region Orders
        [HttpGet]
        public async Task<IActionResult> OrderList()
        {
            return View();
        }
        #endregion
    }
}
