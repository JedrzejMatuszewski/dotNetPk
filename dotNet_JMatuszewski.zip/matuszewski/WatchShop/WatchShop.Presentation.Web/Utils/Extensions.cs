﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace WatchShop.Presentation.Utils
{
    public static class Extensions
    {
        public static string ToScriptStringSafe(this string ob)
        {
            if (ob == null)
                ob = string.Empty;
            return JavaScriptEncoder.Default.Encode(ob);
        }

        public static string ToStringSafe(this object st)
        {
            if (st == null)
                return string.Empty;
            if (string.IsNullOrEmpty(st.ToString()))
                return string.Empty;
            return st.ToString();
        }
    }
}
