﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace WatchShop.Data
{
    public interface IRepository<TEntity> where TEntity : class
    {
        Task<TEntity> GetSingleAsync(Expression<Func<TEntity, bool>> whereCondition);
        void Add(TEntity entity);
        void AddRange(List<TEntity> entities);
        void Delete(TEntity entity);
        void DeleteRange(IEnumerable<TEntity> entities);
        void DeleteWhere(Expression<Func<TEntity, bool>> whereCondition);
        void Attach(TEntity entity);
        void Detach(TEntity entity);
        List<TEntity> GetAll(Expression<Func<TEntity, bool>> whereCondition);
        List<TEntity> GetAll(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includeProperties);
        List<TEntity> GetAll();
        Task<List<TEntity>> GetAllAsync();
        Task<List<TEntity>> GetAllAsync(Expression<Func<TEntity, bool>> whereCondition, bool tracking = true);
        Task<List<TEntity>> GetAllAsync(Expression<Func<TEntity, bool>> predicate, params Expression<Func<TEntity, object>>[] includeProperties);

        int Count(Expression<Func<TEntity, bool>> whereCondition);
        int Count();
        Task<int> CountAsync();
        Task<int> CountAsync(Expression<Func<TEntity, bool>> whereCondition);
        bool Any(Expression<Func<TEntity, bool>> whereCondition);
        bool Any();
        Task<bool> AnyAsync(Expression<Func<TEntity, bool>> whereCondition);
        Task<bool> AnyAsync();
        TEntity GetSingle(Expression<Func<TEntity, bool>> whereCondition);
        TEntity GetSingleInclude(Expression<Func<TEntity, bool>> whereCondition, params Expression<Func<TEntity, object>>[] includeProperties);
        Task<TEntity> GetSingleIncludeAsync(Expression<Func<TEntity, bool>> whereCondition, params Expression<Func<TEntity, object>>[] includeProperties);
        void Edit(TEntity entity);
        void EditRange(List<TEntity> entities);

        int Save();
        Task<int> SaveAsync();
        TEntity Find(int id);
        IQueryable<TEntity> GetQueryable(bool tracking = false);
    }
}
