﻿using DevExtreme.AspNet.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public interface IAddressRepository : IRepository<Address>
    {
        Task<object> GetDataToList(DataSourceLoadOptionsBase loadOptions);
        Task<object> GetDataToListForUser(DataSourceLoadOptionsBase loadOptions, string userId);
        Task<object> GetAddressById(DataSourceLoadOptionsBase loadOptions, int id);
    }
}
