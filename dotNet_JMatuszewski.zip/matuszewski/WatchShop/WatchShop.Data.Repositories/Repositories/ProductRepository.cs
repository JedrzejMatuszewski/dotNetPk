﻿using DevExtreme.AspNet.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class ProductRepository : Repository<Product, ApplicationDbContext>, IProductRepository
    {
        public ProductRepository(ApplicationDbContext context) : base(context)
        {

        }

        public async Task<object> GetDataToList(DataSourceLoadOptionsBase loadOptions)
        {
            var internalQuery = _dbset.Select(x => new
            {
                Id = x.Id,
                PorductName = x.Name,
                MarkName = x.Mark.Name,
                Price = x.Price,
                Qty = x.Qty
            });
            return await DataSourceLoader.LoadAsync(internalQuery, loadOptions);
        }

        public async Task<object> GetDataToList()
        {
            var internalQuery = _dbset.Select(x => new
            {
                Id = x.Id,
                PorductName = x.Name,
                MarkName = x.Mark.Name,
                Price = x.Price,
                Qty = x.Qty
            }).ToList();
            return internalQuery;
        }
    }
}
