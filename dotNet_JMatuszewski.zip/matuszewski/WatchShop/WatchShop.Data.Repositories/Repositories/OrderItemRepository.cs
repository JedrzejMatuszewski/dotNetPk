﻿using DevExtreme.AspNet.Data;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class OrderItemRepository : Repository<OrderItem, ApplicationDbContext>, IOrderItemRepository
    {
        public OrderItemRepository(ApplicationDbContext context) : base(context)
        {

        }

        public async Task<object> GetDataToListForOrder(DataSourceLoadOptionsBase loadOptions, int orderId)
        {
            var specifier = "C";
            var culture = CultureInfo.CreateSpecificCulture("en-US");

            var internalQuery = _dbset.Where(x => x.OrderId == orderId).Select(x => new
            {
                Id = x.Id,
                ProductName = x.Product.Name,
                ProductId = x.Product.Id,
                MarkName = x.Product.Mark.Name,
                Price = x.Product.Price.ToString(specifier, culture),
                Qty = x.Qty,
                TotalPrice = (x.Qty * x.Product.Price).ToString(specifier, culture)
            });
            return await DataSourceLoader.LoadAsync(internalQuery, loadOptions);
        }


        public async Task<object> GetDataToListForOrder(int orderId)
        {
            var specifier = "C";
            var culture = CultureInfo.CreateSpecificCulture("en-US");

            var internalQuery = _dbset.Where(x => x.OrderId == orderId).Select(x => new
            {
                Id = x.Id,
                ProductName = x.Product.Name,
                ProductId = x.Product.Id,
                MarkName = x.Product.Mark.Name,
                Price = x.Product.Price.ToString(specifier, culture),
                Qty = x.Qty,
                TotalPrice = (x.Qty * x.Product.Price).ToString(specifier, culture)
            }).ToList();
            return internalQuery;
        }

    }
}
