﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WatchShop.Application
{
    public class CartVM
    {
        public int CartId { get; set; }
        public string UserId { get; set; }
        public int ItemsCount { get; set; }
    }
}
