﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Application
{
    public class OrderVM
    {
        public Order Order { get; set; }
        public List<OrderItem> Items { get; set; }
        public OrderAddress Adress { get; set; }
        public ApplicationUser User { get; set; }
        public ApplicationUser ReqestUser { get; set; }

        public List<EnumModelBinder<int>> Statuses { get; set; } = new List<EnumModelBinder<int>>();

    }
}
