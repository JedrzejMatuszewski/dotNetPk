﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WatchShop.Application
{
    public class ProductEditVM
    {
        [Required]
        public int ProductId { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Description { get; set; }
        [Required]
        public string Tags { get; set; }
        [Required]
        public int Qty { get; set; }
        [Required]
        public decimal Price { get; set; }
        [Required]
        public int MarkId { get; set; }

        [Required]
        public bool IsGaleryUpdate { get; set; }

        public List<EnumModelBinder<int>> Marks { get; set; } = new List<EnumModelBinder<int>>();

        public IEnumerable<IFormFile> Photos { get; set; }
        public IEnumerable<string> PhotoNames { get; set; }
    }
}
