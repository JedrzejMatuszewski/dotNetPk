﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

namespace WatchShop.Application
{
    public class ProductAddVM
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Qty { get; set; }
        public decimal Price { get; set; }
        public int MarkId { get; set; }
        public string Tags { get; set; }

        public IEnumerable<IFormFile> Photos { get; set; }
        public IEnumerable<string> PhotoNames { get; set; }
    }
}
