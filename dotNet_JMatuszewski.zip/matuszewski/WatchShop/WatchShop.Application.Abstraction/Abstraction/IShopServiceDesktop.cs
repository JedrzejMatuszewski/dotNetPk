﻿using DevExtreme.AspNet.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WatchShop.Application
{
    public interface IShopServiceDesktop
    {
        #region mark
        Task<object> MarkGet(DataSourceLoadOptionsBase loadOptions);
        Task MarkPost(string values);
        Task MarkPut(int key, string values);
        Task MarkDelete(int key);
        #endregion

        #region OrderStatus
        Task<object> OrderStatusGet(DataSourceLoadOptionsBase loadOptions);
        Task OrderStatusPost(string values);
        Task OrderStatusPut(int key, string values);
        Task OrderStatusDelete(int key);
        #endregion

        #region Address
        Task<object> AddressGet(DataSourceLoadOptionsBase loadOptions);
        Task<object> AddressGetForUser(DataSourceLoadOptionsBase loadOptions, string userId);
        Task AddressPost(string values, string userId);
        Task AddressPut(int key, string values);
        Task AddressDelete(int key);
        #endregion

        #region Cart
        Task<object> CartItemsGet(DataSourceLoadOptionsBase loadOptions, int chartId);
        Task CartItemsPut(int key, string values);
        Task CartItemsDelete(int key);
        Task<string> CartTotalValue(int cartId);
        #endregion

        #region ShopOperations
        Task AddNewProduct(ProductAddVM model);
        Task EditProduct(ProductEditVM model);
        Task<ProductEditVM> GetProductEditVM(int productId);
        #endregion

        Task<ProductDetailsVM> ProductGetAll();
        Task<ProductDetailsVM> ProductGetAll(string name, string markFilter);
        Task<ProductVM> GetProduct(int id);
        Task AddToCart(int id, int qty, string userId);
        Task<object> GetUserAddresses(DataSourceLoadOptionsBase loadOptions, string userId);
        Task<object> GetAddressById(DataSourceLoadOptionsBase loadOptions, int addressId);
        Task CreateOrder(NewOrderVM model);

        #region Orders
        Task<object> OrdersGet(DataSourceLoadOptionsBase loadOptions);
        Task<object> OrdersGetForUser(DataSourceLoadOptionsBase loadOptions, string userId);
        Task OrdersDelete(int key);
        Task<OrderVM> OrderDetalis(int orderId);
        Task<object> GetOrdersDataToListForOrder(DataSourceLoadOptionsBase loadOptions, int orderId);
        Task EditOrderStatus(int orderId, int statusId);
        #endregion
    }
}
