﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class MarkConfiguration : IEntityTypeConfiguration<Mark>
    {
        public MarkConfiguration()
        {

        }
        public void Configure(EntityTypeBuilder<Mark> builder)
        {
            builder.HasIndex(x => x.Name);
        }
    }
}
