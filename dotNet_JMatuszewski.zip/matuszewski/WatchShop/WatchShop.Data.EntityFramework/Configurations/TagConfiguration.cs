﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class TagConfiguration : IEntityTypeConfiguration<Tag>
    {
        public TagConfiguration()
        {

        }
        public void Configure(EntityTypeBuilder<Tag> builder)
        {
            builder.HasIndex(x => x.Name);
        }
    }
}
