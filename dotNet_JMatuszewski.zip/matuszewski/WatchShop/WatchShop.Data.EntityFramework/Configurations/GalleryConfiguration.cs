﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class GalleryConfiguration : IEntityTypeConfiguration<Gallery>
    {
        public GalleryConfiguration()
        {

        }
        public void Configure(EntityTypeBuilder<Gallery> builder)
        {
            builder.HasOne(x => x.Product).WithMany().HasForeignKey(x => x.ProductId).OnDelete(DeleteBehavior.Cascade);
            builder.HasIndex(x => x.ImageUrl);
        }
    }
}
