﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class AddressConfiguration : IEntityTypeConfiguration<Address>
    {
        public AddressConfiguration()
        {
                
        }
        public void Configure(EntityTypeBuilder<Address> builder)
        {
            builder.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId);
        }
    }
}
