﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WatchShop.Domain;

namespace WatchShop.Data
{
    public class CartConfiguration : IEntityTypeConfiguration<Cart>
    {
        public CartConfiguration()
        {

        }
        public void Configure(EntityTypeBuilder<Cart> builder)
        {
            builder.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Cascade);
        }
    }
}
